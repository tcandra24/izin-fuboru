$('#btn-logout').on('click', function() {
    $('#form-logout').submit()
})
