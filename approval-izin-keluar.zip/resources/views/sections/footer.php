<footer>
    <div class="py-6 px-6 text-center">
        <p class="mb-0 fs-4">
            Design and Developed by <a href="https://fuboru.co.id/" target="_blank" class="pe-1 text-primary text-decoration-underline">Fuboru Indonesia</a>
        </p>
    </div>
</footer>
