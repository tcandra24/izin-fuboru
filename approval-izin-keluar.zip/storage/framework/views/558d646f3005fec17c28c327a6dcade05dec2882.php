<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Error | <?php echo $__env->yieldContent('title'); ?></title>
        <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/images/logos/favicon.png')); ?>" />
        <link href="<?php echo e(asset('assets/css/styles.min.css')); ?>" rel="stylesheet">
    </head>
    <body>
        <div class="d-flex align-items-center justify-content-center vh-100">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html>
<?php /**PATH E:\Tito\01 Projects\Dev\approval-izin-keluar\resources\views/layouts/error.blade.php ENDPATH**/ ?>