<?php $__env->startSection('title'); ?>
Halaman Tidak Ditemukan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="text-center">
    <h1 class="display-1 fw-bolder">403</h1>
    <p class="fs-3"> <span class="fw-bold text-danger">Opps!</span> Halaman Tidak Diijinkan.</p>
    <p class="lead">
        Anda tidak diijinkan mengakses halaman ini.
    </p>
    <a href="/dashboard" class="btn btn-primary">Kembali ke Dashboard</a>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/sidebarmenu.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/simplebar/dist/simplebar.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Tito\01 Projects\Dev\approval-izin-keluar\resources\views/errors/403.blade.php ENDPATH**/ ?>