<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Approval Izin Keluar | <?php echo $__env->yieldContent('title'); ?></title>
  <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/images/logos/favicon.png')); ?>" />
  <link href="<?php echo e(asset('assets/css/styles.min.css')); ?>" rel="stylesheet">

  <?php echo $__env->yieldContent('page-style'); ?>
</head>

<body>
  <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
    data-sidebar-position="fixed" data-header-position="fixed">

    <?php echo $__env->make('sections/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="body-wrapper">
        <?php echo $__env->make('sections/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container-fluid">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <?php echo $__env->make('sections/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>

  <?php echo $__env->yieldContent('script'); ?>
  <script src="<?php echo e(asset('assets/js/global.js')); ?>"></script>
</body>

</html>
<?php /**PATH E:\Tito\01 Projects\Dev\approval-izin-keluar\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>