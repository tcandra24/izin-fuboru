<?php $__env->startSection('title'); ?>
Log Approval
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 d-flex align-items-stretch">
    <div class="card w-100">
        <div class="card-body p-4">
        <h5 class="card-title fw-semibold mb-4">Log Approval</h5>
        <div class="table-responsive">
            <table class="table text-nowrap mb-0 align-middle">
            <thead class="text-dark fs-4">
                <tr>
                <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">#</h6>
                </th>
                <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Kode Izin</h6>
                </th>
                <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Yang Membuat</h6>
                </th>
                <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Keperluan</h6>
                </th>
                <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Keterangan</h6>
                </th>
                <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Status Lama</h6>
                </th>
                <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Status Baru</h6>
                </th>
                <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Di Approve Oleh</h6>
                </th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($logApproval) > 0): ?>
                    <?php $__currentLoopData = $logApproval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="border-bottom-0"><h6 class="fw-semibold mb-0"><?php echo e($logApproval->firstItem() + $key); ?></h6></td>
                            <td class="border-bottom-0">
                                <p class="mb-0 fw-normal"><?php echo e($log->code_approval); ?></p>
                            </td>
                            <td class="border-bottom-0">
                                <p class="mb-0 fw-normal"><?php echo e($log->pengguna_buat_izin->nama); ?></p>
                            </td>
                            <td class="border-bottom-0">
                                <p class="mb-0 fw-normal"><?php echo e($log->title); ?></p>
                            </td>
                            <td class="border-bottom-0">
                                <p class="mb-0 fw-normal"><?php echo e($log->description); ?></p>
                            </td>
                            <td class="border-bottom-0">
                                <?php if($log->old_status === 'T2'): ?>
                                    <span class="badge rounded-pill bg-info text-white fw-bold">Approve Keluar</span>
                                <?php elseif($log->old_status === 'T3'): ?>
                                    <span class="badge rounded-pill bg-info text-white fw-bold">Approve Masuk</span>
                                <?php elseif($log->old_status === 'A'): ?>
                                    <span class="badge rounded-pill bg-info text-white fw-bold">Aktif</span>
                                <?php elseif($log->old_status=== 'C'): ?>
                                    <span class="badge rounded-pill bg-info text-white fw-bold">Selesai</span>
                                <?php else: ?>
                                    <span class="badge rounded-pill bg-info text-white fw-bold">Status Tidak Ditemukan</span>
                                <?php endif; ?>
                            </td>
                            <td class="border-bottom-0">
                                <?php if($log->new_status === 'T2'): ?>
                                    <span class="badge rounded-pill bg-info text-white fw-bold">Approve Keluar</span>
                                <?php elseif($log->new_status === 'T3'): ?>
                                    <span class="badge rounded-pill bg-info text-white fw-bold">Approve Masuk</span>
                                <?php elseif($log->new_status === 'A'): ?>
                                    <span class="badge rounded-pill bg-info text-white fw-bold">Aktif</span>
                                <?php elseif($log->new_status=== 'C'): ?>
                                    <span class="badge rounded-pill bg-info text-white fw-bold">Selesai</span>
                                <?php else: ?>
                                    <span class="badge rounded-pill bg-info text-white fw-bold">Status Tidak Ditemukan</span>
                                <?php endif; ?>
                            </td>
                            <td class="border-bottom-0">
                                <p class="mb-0 fw-normal"><?php echo e($log->user->nama); ?></p>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8">
                            <div class="alert alert-info text-center" role="alert">
                                Log Approval Masih Kosong
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
            </table>
            <div class="d-flex flex-column justify-content-end my-2">
                <?php echo e($logApproval->links()); ?>

            </div>
        </div>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/sidebarmenu.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Tito\01 Projects\Dev\approval-izin-keluar\resources\views/log-approval/index.blade.php ENDPATH**/ ?>